<?php
/* Define username and password */
$Username = "Admin";
$Password = "1234";